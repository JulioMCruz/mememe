import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <div className="w-full max-w-md mx-auto flex flex-col items-center px-4">
        {/* Doodle illustration */}
        <div className="w-full pt-8 pb-4">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Denver2025-Dxv32HruBPNLZMYbV9Jr3KVD71goTy.png"
            alt="Memecoins doodle illustration"
            width={500}
            height={500}
            className="w-full h-auto"
            priority
          />
        </div>

        {/* Main content */}
        <div className="w-full text-center pb-8">
          <h1 className="text-5xl font-black leading-tight tracking-tight">
            Memecoins
            <br />
            in your pocket
          </h1>
          <p className="text-xl mt-4 text-gray-700">The easiest way to buy, sell and discover</p>

          {/* CTA Button */}
          <div className="mt-12 mb-8">
            <Link
              href="#"
              className="inline-block bg-green-300 text-black font-bold text-2xl px-12 py-4 rounded-full shadow-[0_4px_0_rgba(0,0,0,0.25)] hover:bg-green-400 transition-colors"
            >
              Get started
            </Link>
          </div>

          {/* Footer text */}
          <p className="text-sm text-gray-500 mt-16">
            By using Mememe, you agree to accept our
            <br />
            Terms of Use and Privacy Policy
          </p>
        </div>
      </div>
    </main>
  )
}

