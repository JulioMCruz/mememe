import Link from "next/link"

export default function Ready() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center">
      <div className="w-full max-w-md mx-auto flex flex-col items-center px-4">
        <div className="w-full text-center mb-12">
          <h1 className="text-5xl font-black leading-tight tracking-tight mb-4">
            You're{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-blue-400 to-yellow-400">
              ready
            </span>
          </h1>
          <p className="text-xl text-gray-700">Go big or go home!</p>
        </div>

        {/* Account info card */}
        <div className="w-64 h-32 mb-16 flex items-center justify-center relative">
          {/* Gradient border */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-400 via-cyan-400 to-yellow-400 p-1">
            <div className="absolute inset-0 bg-white rounded-xl"></div>
          </div>

          {/* Content */}
          <div className="relative z-10 text-center">
            <div className="text-3xl font-bold">Bictor</div>
            <div className="w-16 h-px bg-black mx-auto my-2"></div>
            <div className="text-3xl font-bold">$10</div>
          </div>
        </div>

        {/* Start Button */}
        <Link
          href="#"
          className="inline-block bg-gradient-to-r from-purple-400 via-cyan-400 to-yellow-400 text-black font-bold text-2xl px-12 py-4 rounded-full shadow-[0_4px_0_rgba(0,0,0,0.25)] hover:opacity-90 transition-opacity"
        >
          Start
        </Link>
      </div>
    </main>
  )
}

